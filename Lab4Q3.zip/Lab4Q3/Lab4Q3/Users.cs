﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab4Q3
{
    public class Users
    {
        public class Users
        {
            public int MailUSerId { get; set; }

            public String MailUserName { get; set; }

            public string MailUSerPwd { get; set; }

            public DateTime AccountCreationDate { get; set; }

            public String Hobbies { get; set; }
        }
    }
}