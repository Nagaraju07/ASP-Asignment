﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab4Q3
{
    public class MailService
    {
        public void SignIn(string MailUserId, string Password) { }

        public void SignUp(string MailUserId, string UserName, string Password, string hobbies) { }

        public void SendMail() { }

        public void GetMail() { }
    }
}